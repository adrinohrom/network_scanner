import json
import os
import argparse
import requests


def do_ping_sweep(ip, num_of_host):
    ip_parts = ip.split('.')
    network_ip = ip_parts[0] + '.' + ip_parts[1] + '.' + ip_parts[2] + '.'
    scanned_ip = network_ip + str(int(ip_parts[3]) + num_of_host)
    response = os.popen(f'ping -c 2 {scanned_ip}')
    res = response.readlines()
    if len(res) >= 3:
        print(f"[+++] Результаты сканирования: {scanned_ip}[+++]\n{res[2]}", end='\n')
    else:
        print(f"[+++] Хост {scanned_ip} не доступен или не отвечает")


def send_http_request(target, method, headers=None, payload=None):
    # Формируем словарь для HTTP-заголовков
    headers_dict = dict()
    if headers:
        for header in headers:
            try:
                header_name, header_value = header.split(':', 1)
                headers_dict[header_name.strip()] = header_value.strip()
            except ValueError:
                print(f"Неверный формат заголовка: {header}")
                continue

    # Проверяем, что метод поддерживается
    if method not in ["GET", "POST"]:
        print(f"Метод {method} не поддерживается. Используйте GET или POST.")
        return

    try:
        # Выполняем HTTP-запрос с таймаутом
        if method == "GET":
            response = requests.get(target, headers=headers_dict, timeout=10)
        elif method == "POST":
            response = requests.post(target, headers=headers_dict, data=payload, timeout=10)

        # Выводим результат
        print(f"[+++] Response status code: {response.status_code}\n"
              f"[+++] Response headers: {json.dumps(dict(response.headers), indent=4, sort_keys=True)}\n"
              f"[+++] Response content:\n {response.text}")

    except requests.exceptions.Timeout:
        print(f"Время ожидания ответа от {target} истекло.")
    except requests.exceptions.RequestException as e:
        print(f"Ошибка при выполнении запроса к {target}: {e}")
    finally:
        # Закрываем соединение, если оно было установлено
        if 'response' in locals():
            response.close()


def main():
    parser = argparse.ArgumentParser(description='Сканер сети')
    parser.add_argument('task', choices=['scan', 'sendhttp'], help='Сканер сети или отправка HTTP запроса')
    parser.add_argument('-i', '--ip', type=str, help='IP адрес')
    parser.add_argument('-n', '--num_of_hosts', type=int, help='Номера хостов')
    parser.add_argument('-m', '--method', type=str, choices=['GET', 'POST'], help='Method')
    parser.add_argument('-t', '--target', type=str, help='URL')
    parser.add_argument('-hd', '--headers', type=str, nargs='*', help='Headers')
    parser.add_argument('-d', '--data', type=str, help='Данные для отправки в теле запроса')
    args = parser.parse_args()

    if args.task == 'scan':
        if not args.ip or not args.num_of_hosts:
            print("Для задачи 'scan' необходимо указать IP и количество хостов")
            return
        for host_num in range(args.num_of_hosts):
            do_ping_sweep(args.ip, host_num)
    elif args.task == 'sendhttp':
        if not args.target or not args.method:
            print("Для задачи 'sendhttp' необходимо указать target и method")
            return
        send_http_request(args.target, args.method, args.headers, args.data)


if __name__ == "__main__":
    main()